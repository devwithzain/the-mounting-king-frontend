"use client";
import Lenis from "lenis";
import Link from "next/link";
import { tv } from "@/public";
import Image from "next/image";
import { TuserProps } from "@/types";
import { useEffect, useState } from "react";
import { getToken } from "@/utils/get-token";
import { getUserData } from "@/utils/currentUser";
import { Button } from "@/components";

export default function CartPage() {
	const token = getToken();
	const [user, setUser] = useState<TuserProps>();
	useEffect(() => {
		const fetchUserData = async () => {
			const userData = await getUserData(token);
			setUser(userData);
		};
		fetchUserData();
	});
	useEffect(() => {
		const lenis = new Lenis();
		function raf(time: number) {
			lenis.raf(time);
			requestAnimationFrame(raf);
		}

		requestAnimationFrame(raf);
	}, []);
	return (
		<div className="w-full flex gap-5 justify-between padding-x shadow-md min-h-screen bg-[url('/heroBackground.png')] bg-center bg-no-repeat bg-cover overflow-x-hidden pt-40">
			<div className="w-full py-10 pr-5 h-fit border-t border-gray-50">
				<div className="flex justify-between border-b pb-4 items-center">
					<h1 className="font-bold font-Monstrate text-[35px] leading-tight text-black">
						Shopping Cart
					</h1>
				</div>
				<div className="w-full flex justify-between gap-5 pt-10">
					<div className="w-full flex flex-col gap-5">
						<div className="w-full flex flex-col gap-10 border-b border-gray-200 pb-5">
							<div className="w-full flex justify-between gap-10">
								<div className="w-[400px]">
									<Image
										width={600}
										height={600}
										src={tv}
										alt="Black Leather Purse"
										className="w-full object-center object-cover rounded-lg"
									/>
								</div>
								<div className="w-full flex flex-col justify-between gap-2">
									<div className="flex flex-col gap-2">
										<p className="font-Monstrate text-[25px] leading-tight text-black font-bold pb-2">
											Product Title 01
										</p>
										<p className="text-lg leading-tight text-gray-600 font-Monstrate">
											Color:{" "}
											<span className="text-lg leading-tight text-gray-600 font-bold">
												Black
											</span>
										</p>
										<p className="text-lg leading-tight text-gray-600 font-Monstrate">
											Price:{" "}
											<span className="text-lg leading-tight text-gray-600 font-bold">
												$120
											</span>
										</p>
									</div>
									<div>
										<p className="text-xl font-Monstrate leading-tight underline text-red-500 cursor-pointer">
											Remove
										</p>
									</div>
								</div>
							</div>
						</div>
						<div className="w-full flex flex-col gap-10 border-b border-gray-200 pb-5">
							<div className="w-full flex justify-between gap-10">
								<div className="w-[400px]">
									<Image
										width={400}
										height={400}
										src={tv}
										alt="Black Leather Purse"
										className="w-full object-center object-cover rounded-lg"
									/>
								</div>
								<div className="w-full flex flex-col justify-between gap-2">
									<div className="flex flex-col gap-2">
										<p className="font-Monstrate text-[25px] leading-tight text-black font-bold pb-2">
											Product Title 01
										</p>
										<p className="text-lg leading-tight text-gray-600 font-Monstrate">
											Color:{" "}
											<span className="text-lg leading-tight text-gray-600 font-bold">
												Black
											</span>
										</p>
										<p className="text-lg leading-tight text-gray-600 font-Monstrate">
											Price:{" "}
											<span className="text-lg leading-tight text-gray-600 font-bold">
												$120
											</span>
										</p>
									</div>
									<div>
										<p className="text-xl font-Monstrate leading-tight underline text-red-500 cursor-pointer">
											Remove
										</p>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div className="w-[800px] h-fit px-5 rounded-lg py-10 bg-gray-200">
						<h1 className="font-semibold font-Monstrate text-[30px] leading-tight text-black pb-4 border-b border-black/10">
							Order Summary
						</h1>
						<div className="w-full flex flex-col gap-3 justify-between pt-2">
							<div className="w-full flex justify-between py-2 border-b">
								<span className="font-medium font-Monstrate text-[18px] leading-tight text-black">
									Order total
								</span>
								<span className="font-bold font-Monstrate text-[18px] leading-tight text-black">
									$600
								</span>
							</div>
							{user ? (
								<Link
									href="https://buy.stripe.com/test_6oE5ktc4IeJTd9K8ww"
									className="w-full bg-[#F99A03] btn text-center transition-all duration-300 ease-in-out text-white px-6 py-3 text-[20px] rounded-full font-Monstrate leading-tight tracking-tight">
									Checkout
								</Link>
							) : (
								<Link
									href="/login"
									className="w-full bg-[#F99A03] btn text-center transition-all duration-300 ease-in-out text-white px-6 py-3 text-[20px] rounded-full font-Monstrate leading-tight tracking-tight">
									Checkout
								</Link>
							)}
						</div>
					</div>
				</div>
				<div className="w-fit flex items-center justify-between bg-[#F99A03] cursor-pointer rounded-lg group mt-10">
					<Button
						bgcolor="#212121"
						href="/products"
						title="Continue shopping"
						className="bg-white text-black"
						style={{ color: "#fff" }}
					/>
				</div>
			</div>
		</div>
	);
}
