"use client";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";

export default function SuccessPage() {
	const router = useRouter();
	const { session_id } = router.query;
	const [session, setSession] = useState<any>(null);

	useEffect(() => {
		if (session_id) {
			const fetchSession = async () => {
				try {
					const response = await fetch(
						`${process.env.NEXT_PUBLIC_API_URL}/retrieve-session?session_id=${session_id}`,
					);
					const data = await response.json();
					setSession(data);
				} catch (error) {
					console.error("Error fetching session:", error);
				}
			};

			fetchSession();
		}
	}, [session_id]);

	return (
		<div className="container mx-auto py-10">
			<h1 className="text-2xl font-bold"> Payment Successful! </h1>;
			{session && (
				<div className="mt-4">
					<p>
						Thank you for your order, <b>{session.customer_details.name} </b>!
					</p>
					<p> Your payment of ${session.amount_total / 100} was successful.</p>
				</div>
			)}
		</div>
	);
}
