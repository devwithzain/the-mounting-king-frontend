import Card from "./wwd-cards";

export default function Whatwedo() {
	return (
		<div className="w-full relative">
			<div className="w-full padding-x">
				<Card />
			</div>
		</div>
	);
}
